#define OS_LINUX
#define ENABLE_LOGGING 
#define API_EXPORTED


